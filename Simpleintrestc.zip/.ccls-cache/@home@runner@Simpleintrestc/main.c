#include <stdio.h>

int main(void) {
  float p,r,t,si;
  printf("enter p,r,t");
 scanf("%f%f%f",&p,&r,&t);
si = p*r*t/100;
  printf("Simple intrest is %f",si);
  return 0;
}