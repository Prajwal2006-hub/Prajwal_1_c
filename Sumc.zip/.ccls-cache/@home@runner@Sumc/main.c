#include <stdio.h>

int main(void) {
  int a,b, sum;
  printf("enter two number\n");
  scanf("%d%d",&a,&b);
  sum = a + b;
  printf("sum of two number is %d", sum);
  return 0;
}