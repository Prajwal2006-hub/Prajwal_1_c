#include <stdio.h>

int main(void) {
  printf("Hello am Prajwal\n");
  printf("Roll no:17\n");
  return 0;
}